<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Food Tours</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Choose a Food Tutorial</h1>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-primary">← Return to Home</a>
    </div>

    <div class="row g-4">
       <?php
$tours = [
    [
        'title' => 'Meat Tutorial',
        'slug' => 'meat',
        'price' => '₱250',
        'img' => 'https://metro.co.uk/wp-content/uploads/2018/11/sei_38669555-3278.jpg?quality=90&strip=all&w=646',
        'source' => 'https://www.nationalhogfarmer.com/market-news/study-shows-eating-meat-extends-human-life-expectancy-worldwide'
    ],
    [
        'title' => 'Vegetable Tutorial',
        'slug' => 'vegetable',
        'price' => '₱200',
        'img' => 'https://domf5oio6qrcr.cloudfront.net/medialibrary/11499/3b360279-8b43-40f3-9b11-604749128187.jpg',
        'source' => 'https://www.britannica.com/topic/vegetable'
    ],
    [
        'title' => 'Juice Tutorial',
        'slug' => 'juice',
        'price' => '₱150',
        'img' => 'https://assets.clevelandclinic.org/transform/LargeFeatureImage/47cdb246-3c9d-4efb-8b3b-1e6b85567a16/Fruit-Juice-155376375-770x533-1_jpg',
        'source' => 'https://refreshjuice.com.au/blogs/news/10-health-benefits-of-drinking-fresh-juice-every-day'
    ],
    [
        'title' => 'Shake Tutorial',
        'slug' => 'shake',
        'price' => '₱150',
        'img' => 'https://static.toiimg.com/thumb/imgsize-23456,msid-113025195,width-600,resizemode-4/113025195.jpg',
        'source' => 'https://timesofindia.indiatimes.com/life-style/food-news/7-fruit-shakes-for-meal-replacement/articleshow/113025195.cms'
    ],
];
?>




        <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-3">
                <div class="card shadow-sm text-center h-100">
                    <div class="card-body">
                        <a href="<?php echo e($tour['source']); ?>" target="_blank">
    <img src="<?php echo e($tour['img']); ?>" alt="<?php echo e($tour['title']); ?>" class="img-fluid mb-2" style="max-height: 150px; object-fit: cover;"></a>
                        <h5 class="card-title mt-2"><?php echo e($tour['title']); ?></h5>
                        <p class="text-muted"><?php echo e($tour['price']); ?></p>
                        <a href="<?php echo e(route('book', ['topic' => $tour['slug']])); ?>" class="btn btn-primary">
                            Book Now
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\Users\marco\Downloads\FoodService\FoodService\resources\views/tours.blade.php ENDPATH**/ ?>