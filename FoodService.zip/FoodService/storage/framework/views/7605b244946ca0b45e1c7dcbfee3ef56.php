<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chef's Section Page</title>
</head>
<body>
    

<?php $__env->startSection('content'); ?>
<h1 style="font-weight: bold; font-size: 3rem; margin-bottom: 20px;">Chef Section</h1>
<?php $__currentLoopData = $chefs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chef): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 mb-4">
        <div class="card h-100 text-center">
        <img src="<?php echo e(asset('images/' . $chef->image)); ?>" alt="<?php echo e($chef->name); ?>" 
        style="width: 150px; height: auto; object-fit: cover; border-radius: 8px; display: block; margin-left: auto; margin-right: auto;" />
        <div class="card-body">
        <h5 class="card-title"><?php echo e($chef->name); ?></h5>
        <a href="<?php echo e(route('chefs.show', $chef->id)); ?>" class="btn btn-primary">View Profile</a>
        </div>
        </div>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>

</body>
</html>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marco\Downloads\FoodService\FoodService\resources\views/chefs/index.blade.php ENDPATH**/ ?>