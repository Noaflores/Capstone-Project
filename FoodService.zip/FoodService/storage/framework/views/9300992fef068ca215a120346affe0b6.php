<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Page</title>
</head>
<body>


<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4 text-center" style="font-size: 2rem; font-weight: 700;">User Reviews</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <form action="<?php echo e(route('reviews.store')); ?>" method="POST" class="mb-4 p-4 border rounded shadow-sm">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name">Your Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="comment">Your Review:</label>
            <textarea name="comment" class="form-control" rows="4" style="width: 100%;" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary mt-3 border">Submit Review</button>
    </form>

    
    <div class="mt-4">
        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card mb-3 border border-secondary shadow-sm">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($review->name); ?></h5>
                    <p class="card-text"><?php echo e($review->comment); ?></p>
                    <p class="text-muted" style="font-size: 0.8rem;"><?php echo e($review->created_at->diffForHumans()); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No reviews yet. Be the first!</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


</body>
</html>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marco\Downloads\FoodService\FoodService\resources\views/reviews/index.blade.php ENDPATH**/ ?>