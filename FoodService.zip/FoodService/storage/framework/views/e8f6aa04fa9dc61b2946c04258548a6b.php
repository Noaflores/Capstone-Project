<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
</head>
<body>
    

<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="text-3xl font-bold mb-6">Food Service Project</h1>
        <p class="mb-4">Discover curated food tours, private cooking classes, and personalized chef experiences from our talented local experts.</p>

       <img src="<?php echo e(asset('images/FoodTourPreview.gif')); ?>" 
        alt="Food Tour Preview" 
        class="mx-auto mb-6 rounded shadow-lg w-1/2 max-w-md h-auto">



        <a href="<?php echo e(route('tours')); ?>" class="text-blue-600 hover:underline">Explore Food Service &rarr;</a>
    </div>
<?php $__env->stopSection(); ?>


</body>
</html>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marco\Downloads\FoodService\FoodService\resources\views/home.blade.php ENDPATH**/ ?>