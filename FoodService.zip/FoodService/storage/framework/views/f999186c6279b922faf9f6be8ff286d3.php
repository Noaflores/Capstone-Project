<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form for Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


<?php $__env->startSection('content'); ?>

<div class="container">
    <h2 class="mb-4">Confirm Your Booking</h2>

    <div class="card mb-4">
        <div class="card-header">
            <strong>Booking Summary</strong>
        </div>
        <div class="card-body">
            <p><strong>Name:</strong> <?php echo e($bookingData['customer_name'] ?? 'N/A'); ?></p>
            <p><strong>Email:</strong> <?php echo e($bookingData['email'] ?? 'N/A'); ?></p>
            <p><strong>Date:</strong> <?php echo e($bookingData['date'] ?? 'N/A'); ?></p>
            <p><strong>Time Slot:</strong> <?php echo e($bookingData['time_slot'] ?? 'N/A'); ?></p>
            <p><strong>Experience:</strong> <?php echo e($bookingData['experience_title'] ?? 'N/A'); ?></p>
            <p><strong>Price:</strong> ₱<?php echo e(number_format($bookingData['amount'] ?? 0, 2)); ?></p>
        </div>
    </div>

    
    <form id="paymentForm" method="POST" action="<?php echo e(route('payment.process')); ?>">
        <?php echo csrf_field(); ?>

        
        <input type="hidden" name="booking_id" value="<?php echo e($bookingData['booking_id'] ?? ''); ?>">
        <input type="hidden" name="amount" value="<?php echo e($bookingData['amount'] ?? ''); ?>">

        <div class="mb-3">
            <label for="payment_method" class="form-label">Payment Method:</label>
            <select id="payment_method" name="payment_method" class="form-control" required>
                <option value="">Select a method</option>
                <option value="paypal">PayPal</option>
                <option value="stripe">Stripe</option>
            </select>
        </div>

        <div class="d-flex gap-3 mt-3">
            <button type="submit" class="btn btn-outline-success">Purchase</button>
            
            <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-danger">Cancel Purchase</a>
        </div>
    </form>
</div>

<?php if(session('success')): ?>
<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="successModalLabel">Booking Confirmed!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e(session('success')); ?>

            </div>
            <div class="modal-footer">
                <a href="<?php echo e(route('tours')); ?>" class="btn btn-primary">OK</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var successModal = new bootstrap.Modal(document.getElementById('successModal'));
        successModal.show();
    });
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

 </body>
</html>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\marco\Downloads\FoodService\FoodService\resources\views/payment/form.blade.php ENDPATH**/ ?>